/**
 * Created by CWang on 28/02/15.
 */

var connection;

exports.open=function() {
    var mysql = require('mysql');
    connection = mysql.createConnection({
        host: "127.0.0.1",
        user: "root",
        password: "wangbo",
        database: "Integer"
    });

    connection.connect(function (err) {
        if (err) {
            //throw new Error("err");
            //connection=null;
            //delete connection;
            //console.log(err.code);
            //process.exit(err.code);
        }
    });
}

exports.query=function() {
    connection.query("select * from PlusLess10", function (err, rows, fields) {
        if (err) {
            exports.response = null;
            //console.log(err.code);
        } else {
            console.log(rows);
            exports.response = rows;
        }
    });
}
exports.close=function() {
    connection.end(function (err) {
    });
}


/**
 * Created by CWang on 03/03/15.
 */

//var express = require('express'),
//    app     = express(),
connectionpool=null;

exports.init=function() {
  var  mysql = require('mysql');
    connectionpool = mysql.createPool({
            host:"localhost",
            user:"root",
            password:"wangbo",
            database:"Integer"
        });
};
//app.get('/:table', function(req,res){

exports.query=function(params,callBack) {
    connectionpool.getConnection(function (err, connection) {
        if (err) {
            console.log(err);
            //res.statusCode = 503;
            //res.send({
            //    result: 'error',
            //    err: err.code
            //});
        } else {
            console.log(params);
            var qStr="";
            switch (params.type){
                case "getMathPlanfromDB":
                    qStr="SELECT `studentdayplan`.`date`,`studentdayplan`.`mathPlan`"
                    +" FROM `integer`.`studentdayplan`"
                    +" inner join `studentinformation`"
                    +" on `studentinformation`.`studentID` =`studentdayplan`.`studentID`"
                    +" WHERE `studentdayplan`.`date` BETWEEN \'"+params.startDate+"\' AND \'"+ params.endDate+"\'"
                    +" AND `studentinformation`.firstname=\'"+params.studentName+"\'";

                    connection.query(qStr, function (err, rows, fields){
                        if (err) {
                            console.error(err);
                            exports.query.reults="";
                        }else {
                            //console.log(rows);
                            exports.query.results=rows;
                        };
                        connection.release();
                        callBack();

                    });
                    break;
                case "getRecentMistakefromDB":
                    qStr="SELECT `mistakerecord`.`date`,`mistakerecord`.`mathMistake`"
                    +" FROM `integer`.`mistakerecord`"
                    +" inner join `studentinformation`"
                    +" on `studentinformation`.`studentID` =`mistakerecord`.`studentID`"
                    +" WHERE `mistakerecord`.`date` BETWEEN \'"+params.startDate+"\' AND \'"+ params.endDate+"\'"
                    +" AND `studentinformation`.firstname=\'"+params.studentName+"\'";
                     console.log(qStr);
                    connection.query(qStr, function (err, rows, fields){
                        if (err) {
                            console.error(err);
                            exports.query.reults="";
                        }else {
                            //console.log(rows);
                            exports.query.results=rows;
                        };
                        connection.release();
                        callBack();

                    });
                    break;


                case "saveMathPlantoDB"://from current to next week
                    //params.newMathPlan
                    for(var i=0;i<params.newMathPlan.length;i++) {

                        var obj=eval('('+ params.newMathPlan[i]+ ')');
                        qStr="insert into `studentdayplan`( `date`,`mathPlan`,`studentID`)"
                        +" values (\'"+obj.date+"\',\'"+obj.content+"\', "
                        + " (SELECT `s`.`studentID`"
                        + " FROM `studentinformation` `s` "
                        + " WHERE `s`.`firstName`='Joseph') )"
                        + " ON DUPLICATE KEY UPDATE"
                        + "`studentdayplan`.`mathPlan`= \'"+obj.content+"\'";

                        //console.log(qStr);
                        connection.query(qStr, function (err, rows, fields) {
                            if (err) {
                                console.error(err);
                                exports.query.reults = "";
                            } else {
                                //console.log(rows);
                                exports.query.results = rows;
                            };
                        });
                    }
                    connection.release();
                    callBack();
                   break;
                case "saveRecentMistaketoDB":
                   //console.log(params.newMathPlan);
                    for(var i=0;i<params.newMathPlan.length;i++) {

                        var obj=eval('('+ params.newMathPlan[i]+ ')');


                        if(/\S/.test(obj.mathMistake)==false)
                          qStr="DELETE  FROM `mistakerecord`"
                          + " WHERE `mistakerecord`.`studentID`=(SELECT `s`.`studentID`"
                          + " FROM `studentinformation` `s` "
                          + " WHERE `s`.`firstName`='Joseph')"
                          + " AND `mistakerecord`.`date`= \'"+obj.date+"\'";

                        else

                        qStr="insert into `mistakerecord`( `date`,`mathMistake`,`studentID`)"
                        +" values (\'"+obj.date+"\',\'"+obj.mathMistake+"\', "
                        + " (SELECT `s`.`studentID`"
                        + " FROM `studentinformation` `s` "
                        + " WHERE `s`.`firstName`='Joseph') )"
                        + " ON DUPLICATE KEY UPDATE"
                        + " `mistakerecord`.`mathMistake`= \'"+obj.mathMistake+"\'";
                        console.log(qStr);
                        connection.query(qStr, function (err, rows, fields) {
                            if (err) {
                                console.error(err);
                                exports.query.reults = "";
                            } else {
                                //console.log(rows);
                                exports.query.results = rows;
                            };
                        });
                    }
                    connection.release();
                    callBack();
                    break;

            }



};
});
};

exports.close=function(){
    connectionpool.end();
};

/**
 * Created by CWang on 26/02/15.
 */
var db_api= new DB_API();

 var i1 = db_api.connect();

var i2=db_api.query();
var i3=db_api.close();

function DB_API() {
    var connection;

    this.connect = function () {
        var success=true;
        var mysql = require('mysql');
        connection = mysql.createConnection({
            host: "127.0.0.1",
            user: "root",
            password: "wangbo1",
            database: "Integer"
        });

      connection.connect(function (err) {
          if (err) {
              console.log(err.code);
              exit();
          }
      });
    }

    this.query = function () {
        connection.query("select * from PlusLess10", function (err, rows, fields) {
            if (err) {
               exports.response=null;
            } else {
                exports.response=rows;
            }
        });
    };

    this.close = function () {
        connection.end(function (err) {
            if (err) {
                return false;
            } else {
                return true;
            }
        });
    }
}


/**
 * Created by CWang on 24/01/15.
 */
var mysql=require('mysql');

var connection=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"wangbo",
    database:"Integer"
});

//connection.query("use IntegerArithmetic");
    connection.connect(function (err) {
    });

connection.query("select  * from PlusLess10", function(err,rows,fields){
    if(err){
        //console.log(err);
        exports.qErr= err;
        console.log(err);
    }else{
        console.log(rows);
        exports.response= rows;
        //var i;
        //for(var i=0;i<rows.length;i++) {
        //    for (var x in rows[i])
        //        console.log(x + "->" + (rows[i])[x]);
        //    console.log("\n\n");
        //}

    }

});

connection.end(function(err){
    if(err){
        exports.endErr=err;
    }else{
        //console.log("the end");
    }
});

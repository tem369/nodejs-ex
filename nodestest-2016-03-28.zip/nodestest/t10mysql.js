/**
 * Created by CWang on 23/01/15.
 */
//var x=require("./readMySQL.js");

//console.log(x.qErr);

var http = require('http');

var server = http.createServer(function(req, res) {
    res.writeHead(200);
    res.end("x.response");
    //res.end(x.toString());
});
server.listen(8080);

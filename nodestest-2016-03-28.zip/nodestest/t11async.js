/**
 * Created by CWang on 25/01/15.
 */
    var async=require("async");

var  q=async.queue(function(task,callback){
    console.log(task.name);
    callback();
}, 2);

q.drain=function(){
    console.log("all tasks have been done");
}

q.push({name:"worker1"},function(err){
    console.log("worker1 finished");
})
q.push({name:"worker2"},function(){
    console.log("worker2 finished");
})
q.push([{name:"worker3"},{name:"worker4"}],function(err){
    console.log("worker3 worker 4 finished");
})
q.unshift({name:"worker0"},function(err){
    console.log("worker0 finished");
})
//async.waterfall([
//        function (callback){
//            callback(null,3,4);
//                //Math.random(),Math.random());
//        },
//        function (a,b,callback){
//            callback(null,a,b,a*a+b*b);
//        },
//        function (a,b,cc,callback){
//            callback(null,a,b,Math.sqrt(cc));
//        }
//],function (err,a,b,results){
//        if(err)
//        console.log(err);
//        else{
//            console.log(a+","+b+","+results);
//        }
//    }
//
//);

//async.parallelLimit({
//
//   one: function task1(callback){
//
//          setTimeout(function(){
//              console.log("task 1");
//              callback(null,1);
//          },300);
//    },
//
//    two: function task2(callback){
//        setTimeout(function(){
//            console.log("task 2");
//            callback(null,2);
//        },200);
//    },
//
//    three: function task3(callback){
//        setTimeout(function(){
//            console.log("task 3");
//            callback(null,3);
//        },100);
//    }},2,
//
//    function(err, results){
//        if(err)
//        console.log(err);
//        else{
//            console.log(results);
//        }
//    });

//async.series([
//
//    function task1(callback){
//
//          setTimeout(function(){
//              console.log("task 1");
//              callback(null,1);
//          },300);
//    },
//
//    function task2(callback){
//        setTimeout(function(){
//            console.log("task 2");
//            callback(new Error("err in task 2"),2);
//        },200);
//    },
//
//    function task3(callback){
//        setTimeout(function(){
//            console.log("task 3");
//            callback(null,3);
//        },100);
//    }],
//
//    function(err, results){
//        if(err)
//        console.log(err);
//        else{
//            console.log(results);
//        }
//    });


//async.parallel({
//
//        one: function task1(callback){
//
//            setTimeout(function(){
//                console.log("task 1");
//                callback(null,1);
//            },300);
//        },
//
//        two: function task2(callback){
//            setTimeout(function(){
//                console.log("task 2");
//                callback(null,2);
//            },200);
//        },
//
//        three: function task3(callback){
//            setTimeout(function(){
//                console.log("task 3");
//                callback(null,3);
//            },100);
//        }},
//
//    function(err, results){
//        if(err)
//            console.log(err);
//        else{
//            console.log(results);
//        }
//    });
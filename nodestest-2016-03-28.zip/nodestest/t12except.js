/**
 * Created by CWang on 25/01/15.
 */

var fs=require("fs");
fs.readFile("",function(err,data){
    if(err)
    throw err;
    else{
    console.log(data);
    }
});

process.on("uncaughtException",function(err){
    console.log(err);
})
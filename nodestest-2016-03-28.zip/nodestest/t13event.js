/**
 * Created by CWang on 29/01/15.
 */

var events = require("events");
var emitter =  new events.EventEmitter();


emitter.on("ok",test);
function test(dat1,dat2){
    console.log("get ok"+dat1+dat2);
}
emitter.emit("ok",1,2);
emitter.removeListener("ok",test);

emitter.emit("ok",3,4);

/**
 * Created by CWang on 29/01/15.
 */

function circle(radius){
    this.radius=radius;
    this.area=function(){
        return Math.PI * radius * radius;
    }

};

//circle.prototype.area = function () {
//    var radius = this.radius;
//    return Math.PI * radius * radius;
//};
//
//circle.prototype.circumference = function () {
//    return 2 * Math.PI * this.radius;
//};
//
//

var circle2 = new circle(10);
console.log(circle2.area());
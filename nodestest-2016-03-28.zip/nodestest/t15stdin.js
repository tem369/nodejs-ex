/**
 * Created by CWang on 29/01/15.
 */

  var net=require("net");

var server=net.createServer(function(socket){
    socket.end("hello");
});

server.on("close",function(){
   console.log("server is closed");
});
server.on("error",function(){
    switch(error.code()) {
        //exception insufficient permissions to bind to a port
        case "EACCES":
            //Port is already in use
        case "EADDRINUSE":
            console.log(error);
    }

})

server.listen(8080,function(){
    //console.log(server.address());
    //server.close();
});

//server.unref();

//var net = require("net");
//var server = net.createServer(function(socket) {
//    // handle connection
//});
//
//server.listen(0, function() {
//    var address = server.address();
//
//    console.log("Listening on port " + address.port);
//});



//var Stream = require("stream");
//var stream = new Stream();
//var bytes = 0;
//
//stream.writable = true;
//
//stream.write = function(buffer) {
//    bytes += buffer.length;
//};
//
//stream.end = function(buffer) {
//    if (buffer) {
//        stream.write(buffer);
//    }
//
//    stream.writable = false;
//    stream.emit("finish");
//    console.log(bytes + " bytes written");
//};
//
//stream.pipe(stream);
//stream.emit("data", new Buffer("foo"));
//stream.emit("end");
////setInterval(function(){
////    console.log(Math.round(Math.random()*10))
////} ,1000);
//
////var num=0;
////process.stdin.on("data",function(data){
////    var in1 = parseInt( data.toString(),10);
////     if(isFinite(in1))
////     num+=in1;
////    console.log(num);
////    });
////
////process.stdin.resume();
////
//
//
////var sum = 0;
////
//process.stdin.on("data", function(data) {
//    var number = parseInt(data.toString(), 10);
//
//    if (isFinite(number)) {
//        sum += number;
//    }
//
//    console.log(sum);
//});
//
//process.stdin.resume();
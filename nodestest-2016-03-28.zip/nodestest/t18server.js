/**
 * Created by CWang on 02/02/15.
 */

var express = require('express');
var app = express();

var plusLess10 = require("./readMySQL");

app.get('/', function(req, res) {
    res.sendfile('less10.html');
    //res.json({name:"Chengyou"})
});
app.get('/t1front', function(req, res) {
    res.sendfile('t1Front.html');
    //res.json({name:"Chengyou"})
});
app.get('/2.pdf', function(req, res) {
    res.sendfile('2.pdf');
    //res.json({name:"Chengyou"})
});
app.get('/d3', function(req, res) {
    res.sendfile('D3.html');
    //res.json({name:"Chengyou"})
});
app.get('/plusLess10', function(req, res) {
    //res.sendfile('t1Front.html');
    res.json(plusLess10.response);
});

var server = app.listen(8080, function () {

    var host = server.address().address
    var port = server.address().port

    console.log('Example app listening at http://%s:%s', host, port)

})
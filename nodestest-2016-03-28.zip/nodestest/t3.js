/**
 * Created by CWang on 20/01/15.
 */
var fs=require('fs');

fs.readFile("C:/Users/CWang/myapp/hello.js","UTF8",function (err,data){

     if (!err) console.log(err+"\n\n\n\n\n");

    console.log(data);

    //new BufferedReader ("t3.js", { encoding: "utf8" })
    //    .on ("error", function (error){
    //    console.log ("error: " + error);
    //})
    //    .on ("line", function (line){
    //    console.log ("line: " + line);
    //})
    //    .on ("end", function (){
    //    console.log ("EOF");
    //})
    //    .read ();
});
//console.log(buffer.toString());
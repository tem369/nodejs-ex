/**
 * Created by CWang on 21/01/15.
 */

var fs=require('./w_ReadDir.js');

fs.w_ReadDir("C:/Users/CWang/myapp/",function (err,data){

    if (!err) console.log(err+"\n\n\n\n\n");

    console.log(data);

    //new BufferedReader ("t3.js", { encoding: "utf8" })
    //    .on ("error", function (error){
    //    console.log ("error: " + error);
    //})
    //    .on ("line", function (line){
    //    console.log ("line: " + line);
    //})
    //    .on ("end", function (){
    //    console.log ("EOF");
    //})
    //    .read ();
});
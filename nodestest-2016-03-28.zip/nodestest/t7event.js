/**
 * Created by CWang on 22/01/15.
 */
var EventEmitter = require('events').EventEmitter;
var Counter = function(init){
    this.increment=function(){
        init++;
        this.emit("increased",init);
    }
}
Counter.prototype=new EventEmitter();

var counter = new Counter(20);
var doneIncrement=function(count){
    console.log(count);
}
counter.addListener("increased",doneIncrement);


counter.increment();
counter.increment();
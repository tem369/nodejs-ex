/**
 * Created by CWang on 22/01/15.
 */
//var Readable = require('stream').Readable;
//var readable = new Readable;
//var count = 0;
//
//readable._read = function() {
//    if(++count > 10) {
//        return readable.push(null);
//
//    }
//    setTimeout(function() {
//        readable.push(count + "\n");
//    }, 100);
//};
//readable.pipe(process.stdout);

var size = 1000000;
var totl = process.argv[3] || 100;
var buff = [];
for(var i=0; i < totl; i++) {
    buff.push(new Buffer(size));
    process.stdout.write(process.memoryUsage().heapTotal + "\n");
}
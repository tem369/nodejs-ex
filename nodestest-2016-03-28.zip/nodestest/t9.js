/**
 * Created by CWang on 23/01/15.
 */
//setInterval(function() {}, 1e6);
process.on('SIGINT', function() {
    console.log('SIGINT signal received');
    process.exit(1);
});
var i=0;

for(i=0;i<999999;i++)
    console.log(i);
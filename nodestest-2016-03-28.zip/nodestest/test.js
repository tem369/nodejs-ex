
var q=createQuestion("1B2_1_1+8B2_1_2+10B2_1_3+5B2_1_4");
console.log(q);

function createQuestion(qExp){
    var pQExp=qExp.split(",");
    var q=[];
    for(var i=0;i<pQExp.length;i++){
        var subPQExp=pQExp[i].split("+");
        var pQ=[];
        for(var j=0;j<subPQExp.length;j++){
            var qType=subPQExp[j].replace(/\d+/,"");
            var num=parseInt(subPQExp[j].slice(0,subPQExp[j].length-qType.length));
            var q1=createQ(num,qType);
            pQ=pQ.concat(q1);
        }
        pQ=mixQ(pQ);
        q=q.concat(pQ);
    }
    return q;
}

function createQ(num,qType){
    switch (qType){
        case "B2_1_1"://3 digit+3 digit without 0 grouping
            return createNumQ(num,3,3,0);
        case "B2_1_2"://3 digit+3 digit without 1 grouping
            return createNumQ(num,3,3,1);
        case "B2_1_3"://3 digit+3 digit without 2 grouping
            return createNumQ(num,3,3,2);
        case "B2_1_4"://3 digit+3 digit without 3 grouping
            return createNumQ(num,3,3,3);

        case "B2_2_1"://1 digit+2 digit without 0 grouping
            return createNumQ(num,1,2,0);
        case "B2_2_2"://2 digit+1 digit without 0 grouping
            return createNumQ(num,2,1,0);
        case "B2_2_3"://1 digit+2 digit without 1 grouping
            return createNumQ(num,1,2,1);
        case "B2_2_4"://2 digit+1 digit without 10 grouping
            return createNumQ(num,2,1,1);

        case "B2_3_1":
            return createNumQ(num,2,2,0);
        case "B2_3_2":
            return createNumQ(num,2,2,1);
        case "B2_3_3":
            return createNumQ(num,2,2,2);

        case "B2_4_1":
            return createNumQ(num,3,2,0);
        case "B2_4_2":
            return createNumQ(num,2,3,0);
        case "B2_4_3":
            return createNumQ(num,3,2,1);
        case "B2_4_4":
            return createNumQ(num,2,3,1);
        case "B2_4_5":
            return createNumQ(num,3,2,2);
        case "B2_4_6":
            return createNumQ(num,2,3,2);
    }
}
function createNumQ(qNum,num1,num2,regroupNum){
    var plusNum =[];// new Array(qNum);
    for(var i=0;i<qNum;i++){
        plusNum[i]=[];//new Array(2);
    }
    //make sure num1>=num2
    var num2more1=false;
    if (num2>num1){
        num2more1=true;
        var t=num1;
        num1=num2;
        num2=t;
    }
//          create number


    var n1=[];// new Array(num1);
    var n2=[];// new Array(num2);
    var regroupPos =[];// new Array(regroupNum);



    for(var i=0;i<qNum;i++){

        if(regroupNum==0){
            for (var j = 0; j < num1; j++) {
//                        highest bit can not be 0
                var d11=0;
                if(j==num1-1) d11=1;

                var d21=0;
                if(j==num2-1) d21=1;

//                        create two numbers
                n1[j]=getRandom(d11,9);
                if(j<num2)
                    n2[j]=getRandom(d21,9-n1[j]);
            }
        } else{
//                          create regroup bit
            var possiblePos =[];// new Array(num2);
            for(var k=0;k<num2;k++)
                possiblePos[k]=k;
            var store={};
            store.possible=possiblePos;

            for(var j=0;j<regroupNum;j++){
                regroupPos[j]= (store=getOne(store)).obtained;
            }
            regroupPos.sort(); // from small to big

//
            var iR=0; // the current index of regroupPos to be proceesed
            var liR=-1;//the last index of regroupPos to be proceesed
            var d11=0;
            var d21=0;
            for (var j = 0; j < num2; j++) {

                if(j==num1-1) d11=1;
                n1[j] = getRandom(d11, 9);

                if(j==num2-1) d21=1;

                if (iR < regroupNum) {
                    if (j == regroupPos[iR]) {
                        if (liR == -1) {
                            n1[j] = getRandom(1, 9);
                            n2[j] = getRandom(10 - n1[j], 9);
                        } else if (j == regroupPos[liR] + 1) {

                            n2[j] = getRandom(Math.max(9 - n1[j],d21), 9);
                        } else {
                            n1[j] = getRandom(1, 9);
                            n2[j] = getRandom(10 - n1[j], 9);
                        }
                        liR = iR;
                        iR++;
                        continue;
                    }
                };

                if (liR == -1) {
                    if(d21==1 &&9==n1[j]) n1[j]=getRandom(d11, 8);
                    n2[j] = getRandom(d21, 9 - n1[j]);
                }
                else if (j == regroupPos[liR] + 1){
                    if(d21==1 &&8<=n1[j]) n1[j]=getRandom(d11, 7);
                    if(d21==0 &&8<n1[j]) n1[j]=getRandom(d11, 8);
                    n2[j] = getRandom(d21, 8 - n1[j]);
                }
                else {
                    if(d21==1 &&9==n1[j]) n1[j]=getRandom(d11, 8);
                    n2[j] = getRandom(d21, 9 - n1[j]);
                }
            }

            for(var j=num2;j<num1;j++) {
                var d11 = 0;
                if (j == num1 - 1)
                    d11 = 1;
                if (regroupPos[regroupNum - 1] == j - 1)
                    n1[j] = getRandom(d11, 8);
                else
                    n1[j] = getRandom(d11, 9);
            }
        }

        var n1str="";
        var n2str="";
        for(var j=n1.length-1;j>-1;j--){
            n1str += n1[j];
        }
        for(var j=n2.length-1;j>-1;j--){
            n2str += n2[j];
        }
        if(num2more1){
            var t=n1str;
            n1str=n2str;
            n2str=t;
        }
        plusNum[i][0]=parseInt(n1str)
        plusNum[i][1]=parseInt(n2str);
    }

    return plusNum;
}
/**
 * make pQ random
 * @param array pQ
 * @returns {random pQ}
 */
function mixQ(pQ){
    var pQ1=[];
    var store ={};
    store.possible=pQ;
    store.obtained=[];
    var lg=pQ.length;
    for(var i=0;i<lg;i++){
        store=getOne(store);
        pQ1[i]=store.obtained;
    }
    return pQ1;
}

/**
 * get one from possible
 * @param store={
     *         .possble=[possible values]
     *         .obtained from possible
     * @returns {store}
 */
function getOne(store){
    var pos = getRandom(0,store.possible.length-1);
    store.obtained = store.possible[pos];
    store.possible.splice(pos,1);
    return store;
}

function getRandom(min,max){
    return (Math.floor(Math.random() * (max - min + 1)) + min);
}
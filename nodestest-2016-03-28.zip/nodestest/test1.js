var t=dateThreeWeek(new Date());
console.log(t);

function dateThreeWeek(curDate) {
    var dayDate = [{}];
    var curDay;
    var curDayNo;

    dayDate[0] = getDateDay(curDate);

    switch (dayDate[0].day) {
        case "Mon":
            curDay = 0;
            break;
        case "Tue":
            curDay = 1;
            break;
        case "Wed":
            curDay = 2;
            break;
        case "Thu":
            curDay = 3;
            break;
        case "Fri":
            curDay = 4;
            break;
        case "Sat":
            curDay = 5;
            break;
        case "Sun":
            curDay = 6;
//                break;
    };
//        curDayNo=curDay;
    curDate.setDate( curDate.getDate() - 8 - curDay);
    for (var i = 0; i < 21; i++) {
        curDate.setDate(curDate.getDate() + 1);
        dayDate[i] = getDateDay(curDate);
    }
    console.log(dayDate);
    return {dayDate:dayDate,curDayNo:curDay} ;
}
function getDateDay(date){
    var dayDate={};
    dayDate.date = (new String(date.toJSON())).slice(0,10);
    dayDate.day=(date.toString()).slice(0,3);
    return dayDate;
}

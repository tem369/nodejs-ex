/**
 * Created by CWang on 13/03/15.
 */

var str = '1B2_1_1+8B2_1_2+10B2_1_3+5B2_1_';

var res=/\S/.test(str);
console.log(res);
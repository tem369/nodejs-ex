/**
 * Created by CWang on 21/01/15.
 */

exports.w_ReadDir=function w_ReadDir(path,doneReadDir) {

    var fs1 = require('fs');

    fs1.readdir(path, doneReadDir);
}
